package controlador;

import java.sql.SQLException;
import java.util.ArrayList;
import modelo.VO.LideresCargosBgaVO;
import modelo.VO.LideresCostoPromVO;
import modelo.DAO.LideresCargosBgaDAO;
import modelo.DAO.MaterialesProyectosDAO;
import modelo.DAO.LideresCostosPromDAO;
import modelo.VO.MaterialesProyectosVO;

public class ControladorRequerimientos {

    private final MaterialesProyectosDAO materialesProyectosDao;
    private final LideresCargosBgaDAO lideresCargosBgaDao;
    //private final LideresCostosPromDAO lideresCostosPromDao;

    public ControladorRequerimientos(){
        materialesProyectosDao = new MaterialesProyectosDAO();
        lideresCargosBgaDao = new LideresCargosBgaDAO();
        //lideresCostosPromDao = new LideresCostosPromDAO();

    }

    public  ArrayList<MaterialesProyectosVO> consultarMaterialesProyectos() throws SQLException{
        return materialesProyectosDao.TotalesMaterialesProyectos();
    } 

    public ArrayList<LideresCargosBgaVO> consultarLideresCargosBga() throws SQLException {
        return lideresCargosBgaDao.consultarLideresCargosBga();
    }

    public static ArrayList<LideresCostoPromVO> consultarLideresCostoProm() throws SQLException {
        return LideresCostosPromDAO.consultarLideresCostoProm();
    }

}
