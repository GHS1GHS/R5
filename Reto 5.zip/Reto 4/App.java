import vista.VistaRequerimientos;

public class App {
    public static void main(String[] args) {

        //llamar al req 1 : Consulta 1
        VistaRequerimientos.requerimiento1();


        // llamar req 2 : Consulta 4
        VistaRequerimientos.requerimiento2();


        // llamar req   3  : Consulta 5
        VistaRequerimientos.requerimiento3();


    }
}