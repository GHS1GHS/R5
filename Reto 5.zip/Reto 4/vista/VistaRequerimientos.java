package vista;

import java.util.ArrayList;

import modelo.VO.LideresCargosBgaVO;
import modelo.VO.MaterialesProyectosVO;
import modelo.VO.LideresCostoPromVO;

import controlador.ControladorRequerimientos;

public class VistaRequerimientos {

    private static final ControladorRequerimientos controlador = new ControladorRequerimientos();


    public static void requerimiento1() { 

        System.out.println("Requerimiento 1, Consulta 1:");
        System.out.println("Lider Cargo");

        // Llamar al controlador y recibir 
        try
        {
            ArrayList<LideresCargosBgaVO> arregloResultados = controlador.consultarLideresCargosBga();

            // Recorrer Arreglo

            for ( LideresCargosBgaVO registro : arregloResultados){
                System.out.println(registro.getNombre() + "  "  + registro.getCargo());
            }
            

        } catch (Exception e) {
            System.err.println("Oooo! Paso algo " + e.getMessage());
        }

    }

    public static  void requerimiento2(){

        System.out.println("Requerimiento 2, Consulta 4:");
        System.out.println("Nombre_Material Precio_Unidad Total");


        try
        {
            ArrayList<MaterialesProyectosVO> arregloResultados = controlador.consultarMaterialesProyectos();

            // Recorrer Arreglo

            for ( MaterialesProyectosVO registro : arregloResultados){
                System.out.println(registro.getNombre_Material() + "  "  + registro.getPrecio_Unidad() + "  " + registro.getTotal());

            }


        } catch (Exception e) {
            System.err.println("Oooo! Paso algo " + e.getMessage());
        }

    }

    public static void requerimiento3() { 


        System.out.println(" ");
        System.out.println("Requerimiento 3, Consulta 5:");
        System.out.println("Nombre Promedio");

        // Llamar al controlador y recibir 
        try
        {
            ArrayList<LideresCostoPromVO> arregloResultados = ControladorRequerimientos.consultarLideresCostoProm();

            // Recorrer Arreglo

            for ( LideresCostoPromVO registro : arregloResultados){
                System.out.println(registro.getNombre() + "   "  + registro.getPromedio());
            }


        } catch (Exception e) {
            System.err.println("Oooo! Paso algo " + e.getMessage());
        }

    }

    

}
