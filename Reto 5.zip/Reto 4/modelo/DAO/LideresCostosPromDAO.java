package modelo.DAO;

import java.util.ArrayList;
import modelo.VO.LideresCostoPromVO;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.JDBCutilities;

public class LideresCostosPromDAO {

    public static ArrayList<LideresCostoPromVO> consultarLideresCostoProm() throws SQLException{

        ArrayList<LideresCostoPromVO> respuesta = new ArrayList<LideresCostoPromVO>();

            //Consultar BD

            Connection conexion = JDBCutilities.getConnection();
            Statement st = conexion.createStatement();
    
            String query = "SELECT Nombre ||\" \"||Primer_Apellido ||\" \"||Segundo_Apellido Nombre, SUM(c.Cantidad*mc.Precio_Unidad)/COUNT(DISTINCT p.ID_Proyecto) Promedio " +
            "FROM Lider l LEFT JOIN Proyecto p ON l.ID_Lider = p.ID_Lider " +
            "    LEFT JOIN Compra c ON p.ID_Proyecto = c.ID_Proyecto " +
            "    LEFT JOIN MaterialConstruccion mc ON c.ID_MaterialConstruccion = mc.ID_MaterialConstruccion " +
            "WHERE p.Clasificacion = 'Apartaestudio' " +
            "GROUP BY l.ID_Lider " +
            "HAVING COUNT(DISTINCT p.ID_Proyecto) >= 2 " +
            "ORDER BY Promedio " +
            "LIMIT 3";
            
        
            ResultSet rs = st.executeQuery(query);
    
            //Cargar resultados en POO
    
            while( rs.next() ){
                String Nombre = rs.getString("Nombre");
                Double Promedio = rs.getDouble("Promedio");
    
                LideresCostoPromVO registro = new LideresCostoPromVO(Nombre, Promedio);
    
                respuesta.add(registro);
    
            }
        

        return respuesta;

    }
    
}
