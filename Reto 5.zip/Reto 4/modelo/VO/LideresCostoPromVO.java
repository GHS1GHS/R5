package modelo.VO;

public class LideresCostoPromVO {
    private String Nombre;
    private Double Promedio;

    public LideresCostoPromVO(String Nombre, Double Promedio){
        this.Nombre = Nombre;
        this.Promedio = Promedio;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public Double getPromedio() {
        return Promedio;
    }

    public void setPromedio(Double promedio) {
        Promedio = promedio;
    }


}
